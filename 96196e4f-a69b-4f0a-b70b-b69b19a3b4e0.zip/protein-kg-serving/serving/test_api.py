"""Tests for the QA service. Run: pytest -q
They use the offline stub LLM + in-memory graph, so no model server or DB is needed."""
from fastapi.testclient import TestClient
from app.main import app


def test_health():
    with TestClient(app) as c:
        body = c.get("/health").json()
        assert body["status"] == "ok"


def test_ask_returns_grounded_answer():
    with TestClient(app) as c:
        body = c.post("/ask", json={"question": "Which proteins interact with lacZ?"}).json()
        assert "MATCH" in body["cypher"]           # a Cypher query was generated
        assert len(body["evidence"]) > 0           # grounded in real rows
        assert "lacY" in body["answer"]            # expected partner present


def test_ask_handles_unknown_protein():
    with TestClient(app) as c:
        body = c.post("/ask", json={"question": "interactions of zzzZ?"}).json()
        assert body["evidence"] == []
        assert "No matching" in body["answer"]
