"""
The QA pipeline: natural-language question -> Cypher -> graph result -> answer.

This wraps the existing knowledge-graph QA logic so it can be called from both the
REST API and the MCP server without duplicating anything.
"""
from .llm_client import LLMClient
from .graph import GraphClient

_SYSTEM = (
    "You translate questions about an E. coli protein interaction graph into a single "
    "read-only Cypher query. Nodes are (:Protein {name}). Relationships are "
    "[:INTERACTS_WITH {score}]. Return only the Cypher query, no prose."
)


class QAPipeline:
    def __init__(self) -> None:
        self.llm = LLMClient()
        self.graph = GraphClient()

    async def answer(self, question: str) -> dict:
        cypher = await self.llm.complete(_SYSTEM, question)
        rows = self.graph.run(cypher)
        return {
            "question": question,
            "cypher": cypher,          # the generated query, shown for traceability
            "evidence": rows,          # the graph rows the answer is grounded in
            "answer": _summarize(question, rows),
            "backend": {
                "llm": "stub" if self.llm.is_stub else self.llm.model,
                "graph": "in-memory" if self.graph.is_in_memory else "neo4j",
            },
        }

    def close(self) -> None:
        self.graph.close()


def _summarize(question: str, rows: list[dict]) -> str:
    if not rows:
        return "No matching interactions were found in the graph."
    partners = ", ".join(f"{r['partner']} (score {r['score']})" for r in rows)
    return f"Top interaction partners: {partners}."
