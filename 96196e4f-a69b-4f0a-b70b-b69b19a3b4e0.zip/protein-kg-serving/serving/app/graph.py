"""
Graph backend.

Runs read-only Cypher against Neo4j when NEO4J_URI is set; otherwise serves a
tiny in-memory sample graph so the service works with no database running. The
in-memory path supports only the small query shape the stub LLM produces, which
is enough for a local demo and the test suite.

Env vars:
  NEO4J_URI       e.g. bolt://neo4j:7687 (unset -> in-memory sample)
  NEO4J_USER      default "neo4j"
  NEO4J_PASSWORD  password
"""
import os
import re
from typing import Any

# A handful of E. coli proteins and interactions, standing in for the real graph.
_SAMPLE_EDGES = [
    ("lacZ", "lacY", 0.98), ("lacZ", "lacA", 0.95), ("lacZ", "lacI", 0.90),
    ("lacY", "lacA", 0.92), ("rpoA", "rpoB", 0.99), ("rpoA", "rpoC", 0.97),
    ("rpoB", "rpoC", 0.99), ("dnaA", "dnaB", 0.94), ("dnaB", "dnaC", 0.93),
    ("recA", "lexA", 0.96),
]


class GraphClient:
    def __init__(self) -> None:
        self.uri = os.getenv("NEO4J_URI", "")
        self._driver = None
        if self.uri:
            from neo4j import GraphDatabase
            self._driver = GraphDatabase.driver(
                self.uri,
                auth=(os.getenv("NEO4J_USER", "neo4j"), os.getenv("NEO4J_PASSWORD", "")),
            )

    @property
    def is_in_memory(self) -> bool:
        return self._driver is None

    def close(self) -> None:
        if self._driver is not None:
            self._driver.close()

    def run(self, cypher: str) -> list[dict[str, Any]]:
        if self._driver is None:
            return self._run_in_memory(cypher)
        # Guard: this service only ever issues read queries.
        if not _is_read_only(cypher):
            raise ValueError("Only read-only Cypher is permitted.")
        with self._driver.session() as session:
            return [dict(r) for r in session.run(cypher)]

    @staticmethod
    def _run_in_memory(cypher: str) -> list[dict[str, Any]]:
        m = re.search(r"\{name:\s*'([^']+)'\}", cypher)
        if not m:
            return []
        protein = m.group(1)
        rows = [
            {"partner": b, "score": s} for a, b, s in _SAMPLE_EDGES if a == protein
        ]
        rows.sort(key=lambda r: r["score"], reverse=True)
        return rows[:5]


def _is_read_only(cypher: str) -> bool:
    banned = ("CREATE", "DELETE", "MERGE", "SET", "REMOVE", "DROP", "DETACH")
    upper = cypher.upper()
    return not any(word in upper for word in banned)
