"""
MCP server exposing the knowledge-graph QA pipeline as a tool.

Any MCP-compatible client (an agent framework, an IDE assistant, a coding harness)
can call `ask_protein_graph` and get back a grounded answer together with the Cypher
query and the evidence rows. This is the "integrating services such as MCP servers"
piece: the same pipeline that serves HTTP also serves agents over stdio.

Run:  python -m app.mcp_server
"""
from mcp.server.fastmcp import FastMCP

from .pipeline import QAPipeline

mcp = FastMCP("protein-kg-qa")
_pipeline = QAPipeline()


@mcp.tool()
async def ask_protein_graph(question: str) -> dict:
    """Answer a question about the E. coli protein interaction graph.

    Returns the answer, the generated Cypher query, and the evidence rows the
    answer was grounded in, so the result stays traceable.
    """
    return await _pipeline.answer(question)


if __name__ == "__main__":
    mcp.run()  # stdio transport by default
