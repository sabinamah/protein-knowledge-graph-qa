"""
LLM backend client.

Talks to any OpenAI-compatible chat endpoint. That is deliberate: a self-managed
vLLM server, an inference gateway, or a hosted API all expose the same
`/v1/chat/completions` interface, so the same client works against all of them by
changing only environment variables -- no code change to swap models or providers.

Env vars:
  LLM_BASE_URL   base URL of the OpenAI-compatible endpoint
                 (e.g. http://vllm:8000/v1). If unset, a local stub is used so the
                 service runs end-to-end without a model server.
  LLM_API_KEY    bearer token (optional for a self-managed endpoint)
  LLM_MODEL      model name to request (default: "local-model")
"""
import os
import httpx


class LLMClient:
    def __init__(self) -> None:
        self.base_url = os.getenv("LLM_BASE_URL", "").rstrip("/")
        self.api_key = os.getenv("LLM_API_KEY", "")
        self.model = os.getenv("LLM_MODEL", "local-model")

    @property
    def is_stub(self) -> bool:
        # With no endpoint configured, we fall back to a deterministic stub.
        return not self.base_url

    async def complete(self, system: str, user: str) -> str:
        if self.is_stub:
            return self._stub(user)

        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": 0.0,
        }

        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(
                f"{self.base_url}/chat/completions", json=payload, headers=headers
            )
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"].strip()

    @staticmethod
    def _stub(user: str) -> str:
        """
        Deterministic offline stand-in for the model. It extracts a protein name
        the question mentions and emits a Cypher query in the same shape the real
        prompt asks for, so the pipeline can be run and tested without a GPU.
        """
        import re
        m = re.search(r"\b([a-z]{3}[A-Z]?)\b", user)
        protein = m.group(1) if m else "lacZ"
        return (
            "MATCH (p:Protein {name: '" + protein + "'})-[r:INTERACTS_WITH]->(q:Protein) "
            "RETURN q.name AS partner, r.score AS score ORDER BY r.score DESC LIMIT 5"
        )
