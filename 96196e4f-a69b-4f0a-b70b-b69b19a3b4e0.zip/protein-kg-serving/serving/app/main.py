"""
REST API over the protein knowledge-graph QA pipeline.

Endpoints:
  GET  /health   liveness + which backends are wired up (for observability)
  POST /ask      {"question": "..."} -> answer + generated Cypher + evidence rows
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from pydantic import BaseModel

from .pipeline import QAPipeline

pipeline: QAPipeline | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global pipeline
    pipeline = QAPipeline()
    yield
    pipeline.close()


app = FastAPI(title="Protein KG QA", version="1.0", lifespan=lifespan)


class AskRequest(BaseModel):
    question: str


@app.get("/health")
async def health() -> dict:
    return {
        "status": "ok",
        "llm": "stub" if pipeline.llm.is_stub else pipeline.llm.model,
        "graph": "in-memory" if pipeline.graph.is_in_memory else "neo4j",
    }


@app.post("/ask")
async def ask(req: AskRequest) -> dict:
    return await pipeline.answer(req.question)
