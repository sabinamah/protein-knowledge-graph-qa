# Protein KG QA — Serving Layer

A serving layer around a protein knowledge-graph question-answering pipeline:
a **REST API**, an **MCP server**, and a **Docker Compose** stack. It turns a
notebook-style QA pipeline into a service that other tools and agents can call.

The LLM backend is any **OpenAI-compatible endpoint** — a self-managed
[vLLM](https://github.com/vllm-project/vllm) server, an inference gateway, or a
hosted API — selected entirely through environment variables. With none configured,
the service runs against a built-in **offline stub LLM and in-memory sample graph**,
so you can start it and run the tests with no GPU and no database.

## What's here
```
serving/
  app/
    llm_client.py   OpenAI-compatible LLM client (+ offline stub)
    graph.py        Neo4j client (+ in-memory sample graph), read-only guard
    pipeline.py     question -> Cypher -> graph -> grounded answer
    main.py         FastAPI REST API  (GET /health, POST /ask)
    mcp_server.py   MCP server exposing the pipeline as a tool
  test_api.py       pytest suite (runs fully offline)
  Dockerfile
  requirements.txt
docker-compose.yml  API + Neo4j
.env.example
```

## Run locally (offline, no GPU)
```bash
cd serving
pip install -r requirements.txt
uvicorn app.main:app --port 8080

curl localhost:8080/health
curl -X POST localhost:8080/ask -H 'content-type: application/json' \
     -d '{"question": "Which proteins interact with lacZ?"}'
```
The response includes the generated Cypher and the evidence rows, so every answer
is traceable back to the graph.

## Run the tests
```bash
cd serving && pytest -q
```

## Use a real inference endpoint
Set the endpoint and model, then start normally:
```bash
export LLM_BASE_URL=http://localhost:8000/v1   # your vLLM / gateway
export LLM_MODEL=Qwen2.5-7B-Instruct
uvicorn app.main:app --port 8080
```

## Run the MCP server
```bash
cd serving
python -m app.mcp_server
```
Exposes one tool, `ask_protein_graph`, over stdio for any MCP-compatible client
(agent framework, IDE assistant, coding harness).

## Docker Compose (API + Neo4j)
```bash
docker compose up --build
# LLM_BASE_URL unset -> API uses the offline stub; set it to use a real model.
```

## Design notes
- One pipeline, two interfaces (HTTP and MCP) — no duplicated logic.
- Provider-agnostic by design: swapping model or provider is an env-var change.
- Read-only Cypher is enforced before any query reaches Neo4j.
- `/health` reports which backends are active, for basic observability.
